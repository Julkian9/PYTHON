def potencia(base,exponente):
        print("El resultado del exponente es: ",base**exponente)
def redondear(numero):
        print("El numero redondeado es: ",round(numero)) 