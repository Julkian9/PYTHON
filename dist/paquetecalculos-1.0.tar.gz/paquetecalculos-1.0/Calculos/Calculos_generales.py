def sumar(op1,op2):
    print("El resultado de la suma es: ",op1+op2)
def restar(op1,op2):
    print("El resultado de la resta es: ",op1-op2)
def Multiplicar(op1,op2):
    print("El resultado de la multiplicacion es: ",op1*op2)   
def dividir(op1,op2):
    print("El resultado de la division es: ",op1/op2)

def potencia(base,exponente):
        print("El resultado del exponente es: ",base**exponente)
def redondear(numero):
        print("El numero redondeado es: ",round(numero)) 