from setuptools import setup

setup(

    name="PaqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Julian",
    author_email="jjmafla@emcali.com.co",
    packages=["Calculos","Calculos.Redondeo_y_Potencia"]
    
)